module.exports = {
    extends: '../../babel.config.js'
}
